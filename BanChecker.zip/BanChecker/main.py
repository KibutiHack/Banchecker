import discord
import os
from discord.ext import commands
import sys
import traceback
import datetime
import asyncio
import random
import ctypes
from colorama import Fore
from dotenv import load_dotenv

intents = discord.Intents.default()
intents.typing = False
intents.presences = False
intents.members = True

client = commands.Bot(command_prefix = "!", intents=intents, activity=discord.Activity(type=discord.ActivityType.watching, name="Watchdog / Staff Bans"))
client.remove_command("help")

for filename in os.listdir('./cogs'):
    if filename.endswith('.py'):
        client.load_extension(f'cogs.{filename[:-3]}')

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        embed=discord.Embed(title="Error!", url="\n", description=f"", color=0x00d0ff)
        embed.add_field(name="Command Not Found", value="`!help`\n`!check (uuid) (banid)`", inline=False)
        await ctx.send(embed=embed)
    elif isinstance(error, commands.MissingRequiredArgument):
        embed=discord.Embed(title="Error!", url="\n", description=f"", color=0x00d0ff)
        embed.add_field(name="Incorrect Usage", value="`!check (uuid) (banid)`", inline=False)
        await ctx.send(embed=embed)
    else:
        print('Ignoring exception in command {}:'.format(ctx.command), file=sys.stderr)
        traceback.print_exception(type(error), error, error.__traceback__, file=sys.stderr)

@client.event
async def on_ready():
    os.system("")
    ctypes.windll.kernel32.SetConsoleTitleW(f"Watchdog Ban Checker | Logged in as {client.user.name}#{client.user.discriminator}")
    print(f"""

                    {Fore.LIGHTCYAN_EX}██████╗  █████╗ ███╗   ██╗ {Fore.WHITE}    ██████╗██╗  ██╗███████╗ ██████╗██╗  ██╗███████╗██████╗ 
                    {Fore.LIGHTCYAN_EX}██╔══██╗██╔══██╗████╗  ██║ {Fore.WHITE}   ██╔════╝██║  ██║██╔════╝██╔════╝██║ ██╔╝██╔════╝██╔══██╗
                    {Fore.LIGHTCYAN_EX}██████╔╝███████║██╔██╗ ██║ {Fore.WHITE}   ██║     ███████║█████╗  ██║     █████╔╝ █████╗  ██████╔╝
                    {Fore.LIGHTCYAN_EX}██╔══██╗██╔══██║██║╚██╗██║ {Fore.WHITE}   ██║     ██╔══██║██╔══╝  ██║     ██╔═██╗ ██╔══╝  ██╔══██╗
                    {Fore.LIGHTCYAN_EX}██████╔╝██║  ██║██║ ╚████║ {Fore.WHITE}   ╚██████╗██║  ██║███████╗╚██████╗██║  ██╗███████╗██║  ██║
                    {Fore.LIGHTCYAN_EX}╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ {Fore.WHITE}    ╚═════╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
                                                                                      
    """)
    print(f"{Fore.LIGHTBLACK_EX}[{Fore.WHITE}INFO{Fore.LIGHTBLACK_EX}] {Fore.WHITE}» {Fore.LIGHTCYAN_EX}Admin Interface has been started.")

load_dotenv()
token = os.getenv('TOKEN')
client.run(token)