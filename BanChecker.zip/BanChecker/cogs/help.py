import discord
import os
from discord.ext import commands
import sys
import traceback
import datetime
import asyncio
import random
import ctypes
from colorama import Fore

class help(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.Cog.listener()
    async def on_ready(self):
        print(f"{Fore.LIGHTBLACK_EX}[{Fore.WHITE}INFO{Fore.LIGHTBLACK_EX}] {Fore.WHITE}» {Fore.LIGHTCYAN_EX}Help Cog has been Loaded.")

    @commands.command()
    async def help(self, ctx):
        embed=discord.Embed(title="Help", url="\n", description=f"", color=0x00d0ff)
        embed.add_field(name="General", value="`!help (Displays this)`\n`!check (uuid) (banid)`", inline=False)
        await ctx.send(embed=embed)

def setup(client):
    client.add_cog(help(client))