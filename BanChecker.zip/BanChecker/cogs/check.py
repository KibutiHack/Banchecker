import discord
import os
from discord.ext import commands
import sys
import requests
import traceback
import datetime
import asyncio
import random
import ctypes
from colorama import Fore

class check(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.Cog.listener()
    async def on_ready(self):
        print(f"{Fore.LIGHTBLACK_EX}[{Fore.WHITE}INFO{Fore.LIGHTBLACK_EX}] {Fore.WHITE}» {Fore.LIGHTCYAN_EX}Check Cog has been Loaded.")

    @commands.command()
    async def check(self, ctx, uuid, banid):
        if (ctx.channel.id == 902430867425751130):
            try:
                banInformation = requests.get(f"https://www.hypixel.net/api/players/{uuid}/ban/{banid}", headers = {"xf-api-key": "LnM-qSeQqtJlJmJnVt76GhU-SoiolWs9"}).json()
                print(banInformation)
                extracted = banInformation["punishmentCategory"]
                reason = banInformation["reason"]
                duration = banInformation["duration"]
                length = (duration / (60*60*24*1000))
                if extracted == "other":
                    banType = "Staff"
                elif extracted == "hacks":
                    banType = "Watchdog"
                embed=discord.Embed(title="Ban Information Successfully Fetched!", url="\n", description=f"", color=0x00d0ff)
                embed.add_field(name="Ban Type", value=f"`{banType}`", inline=False)
                embed.add_field(name="Reason", value=f"`{reason}`", inline=False)
                embed.add_field(name="Duration", value=f"`{length} Days`", inline=False)
                await ctx.send(embed=embed)
            except KeyError:
                embed=discord.Embed(title="An error occured while fetching ban information!", url="\n", description=f"", color=0x00d0ff)
                embed.add_field(name="Error", value=f"`{banInformation}`", inline=False)
                await ctx.send(embed=embed)
            


def setup(client):
    client.add_cog(check(client))